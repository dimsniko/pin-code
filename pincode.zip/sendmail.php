<!-- <?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->setLanguage('ru', 'phpmailer/language/');
$mail->IsHTML(true);

// От кого письмо
$mail->setFrom('site@pin-code.pro', 'С Сайта');
// Кому отправить
$mail->addAddress('support@pin-code.pro');
// Тема письма
$mail->Subject = 'Форма обратной связи';

// Тело письма
$body = '<h1>Заявка</h1>';

if(trim(!empty($_POST['name']))) {
    $body.='<p><strong>Имя:</strong> '.$_POST['name'].'</p>';
}
if(trim(!empty($_POST['email']))) {
    $body.='<p><strong>E-mail:</strong> '.$_POST['email'].'</p>';
}
if(trim(!empty($_POST['message']))) {
    $body.='<p><strong>Сообщение:</strong> '.$_POST['message'].'</p>';
}

// Отправляем
if (!$mail->send()) {
    $message = 'Ошибка';
} else {
    $message = 'Данные отправлены';
}

$response = ['message' => $message];

header('Content-type: application/json');
echo json_encode($response);

?> -->

<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';

// Отключение вывода ошибок
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->setLanguage('ru', 'phpmailer/language/');
$mail->IsHTML(true);

// От кого письмо
$mail->setFrom('site@pin-code.pro', 'С Сайта');
// Кому отправить
$mail->addAddress('support@pin-code.pro');
// Тема письма
$mail->Subject = 'Форма обратной связи';

// Тело письма
$body = '<h1>Заявка</h1>';

if (trim(!empty($_POST['name']))) {
    $body .= '<p><strong>Имя:</strong> ' . htmlspecialchars($_POST['name']) . '</p>';
}
if (trim(!empty($_POST['email']))) {
    $body .= '<p><strong>E-mail:</strong> ' . htmlspecialchars($_POST['email']) . '</p>';
}
if (trim(!empty($_POST['message']))) {
    $body .= '<p><strong>Сообщение:</strong> ' . htmlspecialchars($_POST['message']) . '</p>';
}

$mail->Body = $body;

// Отправляем
try {
    if (!$mail->send()) {
        $message = 'Ошибка отправки: ' . $mail->ErrorInfo;
    } else {
        $message = 'Данные отправлены';
    }
} catch (Exception $e) {
    $message = 'Ошибка: ' . $e->getMessage();
}

$response = ['message' => $message];

echo json_encode($response);
